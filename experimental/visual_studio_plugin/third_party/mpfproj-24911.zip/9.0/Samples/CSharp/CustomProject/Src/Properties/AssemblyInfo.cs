﻿/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Microsoft.VisualStudio.Project.Samples.CustomProject")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Microsoft")]
[assembly: AssemblyProduct("Microsoft.VisualStudio.Project.Samples.CustomProject")]
[assembly: AssemblyCopyright("Copyright © Microsoft 2008")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("d2711c50-1063-4d9d-a00b-fe78b59cdc68")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: CLSCompliant(false)]