/// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Runtime.InteropServices;
using Microsoft.VisualStudio.Project;

namespace Microsoft.VisualStudio.Project.Samples.NestedProject
{
	[ComVisible(true), Guid("C43AD3DC-7468-48e1-B4D2-AAC0C74A0109")]
	public class NestedProjectBuildPropertyPage : BuildPropertyPage
	{
	}
}
