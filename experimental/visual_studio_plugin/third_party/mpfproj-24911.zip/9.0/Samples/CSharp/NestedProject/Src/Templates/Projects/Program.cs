#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace %namespace%
{
	class %className%
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Hello");

		}
	}
}
