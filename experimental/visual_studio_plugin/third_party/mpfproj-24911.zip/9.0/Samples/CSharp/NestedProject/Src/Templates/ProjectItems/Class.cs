#region Using directives

using System;
using System.Collections.Generic;
using System.Text;

#endregion

namespace %namespace%
{
    class %className%
    {
    }
}
