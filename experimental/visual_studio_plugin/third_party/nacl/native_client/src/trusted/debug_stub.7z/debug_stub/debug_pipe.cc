/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#include "native_client/src/shared/platform/nacl_log.h"
#include "native_client/src/trusted/debug_stub/debug_packet.h"
#include "native_client/src/trusted/debug_stub/debug_pipe.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_socket.h"
#include "native_client/src/trusted/debug_stub/debug_util.h"


DebugPipe::DebugPipe(DebugStream *io_ptr) 
  : io(0),
    flags(0) {
	io = io_ptr;
}

DebugPipe::~DebugPipe() {
	// Free IO PTR
	if (io)
	{
		io = 0;
		delete io;
	}
}

void DebugPipe::IgnoreAck(int ignore) {
  if (ignore)
    flags |= DPF_IGNORE_ACK;
  else
    flags &= ~DPF_IGNORE_ACK;
}


DSResult DebugPipe::SendPacket(DebugPacket *pkt) {
  DSResult res;
  char ch;

  // If we are ignoring ACKs..
  if (flags & DPF_IGNORE_ACK)
    return SendPacketOnly(pkt);

  do {
    res = SendPacketOnly(pkt);
    if (res == DS_ERROR)
      return DS_ERROR;
    
    if (io->GetChar(&ch) == DS_ERROR)
		  return DS_ERROR;
    
    // Retry if we didn't get a '+'
  } while (ch != '+');

  return DS_OK;
}

DSResult DebugPipe::SendPacketOnly(DebugPacket *pkt) {	
	string str;

	pkt->GetPayload(str);
	const char *ptr = (const char *) str.data();
	char ch;

	// Signal start of response
	if (io->PutChar('$') == DS_ERROR)
		return DS_ERROR;
	
	char run_xsum = 0;
	char seq;

	int  offs = 0;

	// If there is a sequence, send as two nibble 8bit value + ':'
	if (pkt->GetSequence(&seq) == DS_OK) {
		ch = debug_int_to_nibble(seq >> 4);
		if (io->PutChar(ch) == DS_ERROR)
			return DS_ERROR;
		run_xsum += ch;

		ch = debug_int_to_nibble(seq & 0xF);
		if (io->PutChar(ch) == DS_ERROR)
			return DS_ERROR;
		run_xsum += ch;

		ch = ':';
		if (io->PutChar(ch) == DS_ERROR)
			return DS_ERROR;
		run_xsum += ch;
	}
	
	// Send the main payload
	while (ch = ptr[offs++]) {
		if (io->PutChar(ch) == DS_ERROR)
			return DS_ERROR;
		run_xsum += ch;
	}

	// Send XSUM as two nible 8bit value preceeded by '#'
	if (io->PutChar('#') == DS_ERROR)
		return DS_ERROR;

	if (io->PutChar(debug_int_to_nibble(run_xsum >> 4)) == DS_ERROR)
		return DS_ERROR;

	if (io->PutChar(debug_int_to_nibble(run_xsum & 0xF)) == DS_ERROR)
		return DS_ERROR;

	return DS_OK;
}


// Attempt to receive a packet
DSResult DebugPipe::GetPacket(DebugPacket *pkt) {
	char run_xsum, fin_xsum, ch;

  // If nothing is waiting, return NONE
  if (io->CanRead() == DS_NONE)
    return DS_NONE;

  // Toss characters until we see a start of command
	do {
		if (io->GetChar(&ch) == DS_ERROR)
			return DS_ERROR;
	} while (ch != '$');

 retry:
  // If nothing is waiting, return NONE
  if (io->CanRead() == DS_NONE)
    return DS_NONE;

	// Clear the stream
	pkt->Clear();

	// Prepare XSUM calc
	run_xsum = 0;
	fin_xsum = 0;

	// Stream in the characters
	while (1) {
		if (io->GetChar(&ch) == DS_ERROR)
			return DS_ERROR;

		// If we see a '#' we must be done with the data
		if (ch == '#')
			break;

		// If we see a '$' we must have missed the last cmd
		if (ch == '$')
			goto retry;
		
		// Keep a running XSUM
		run_xsum += ch;
		pkt->AddRawChar(ch);
	}
	
	// Get two Nibble XSUM
	if (io->GetChar(&ch) == DS_ERROR)
		return DS_ERROR;
	fin_xsum  = debug_nibble_to_int(ch) << 4;

	if (io->GetChar(&ch) == DS_ERROR)
		return DS_ERROR;
	fin_xsum |= debug_nibble_to_int(ch);

	// If the XSUMs don't match, signal bad packet
	if (fin_xsum == run_xsum) {
		if (io->PutChar('+') == DS_ERROR)
			return DS_ERROR;

		// If we have a sequence number
		if (pkt->GetSequence(&ch) == DS_OK)
		{
			// Respond with Sequence number
			char seq0 = debug_int_to_nibble(ch >> 4);
			char seq1 = debug_int_to_nibble(ch & 0xF);

			if (io->PutChar(seq0) == DS_ERROR)
				return DS_ERROR;

			if (io->PutChar(seq1) == DS_ERROR)
				return DS_ERROR;
		}
	}
	else {
    // Resend a bad XSUM and look for retransmit
		io->PutChar('-');
		goto retry;
	}

	return DS_OK;
}


