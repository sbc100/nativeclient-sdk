/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#include "native_client/src/shared/platform/nacl_log.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_socket_impl.h"
#include "native_client/src/trusted/debug_stub/debug_socket.h"

static const char *StateToString(DebugSocket::DSState state) {
  switch (state) {
    case DebugSocket::DSS_INVALID: return "INVALID";
    case DebugSocket::DSS_UNBOUND: return "UNBOUND";
    case DebugSocket::DSS_BOUND: return "BOUND";
    case DebugSocket::DSS_LISTEN: return "LISTEN";
    case DebugSocket::DSS_CONNECTED: return "CONNECTED";
    default:
      break;
  }

  return "<UNKNOWN>";
}

DebugSocket::DebugSocket() :  state(DSS_INVALID) {}

DebugSocket::~DebugSocket() {
  if (handle != (DebugHandle) -1)
    Destruct();
}

DSResult DebugSocket::Construct() {
  if (state != DSS_INVALID) {
      NaClLog(LOG_ERROR, "Socket can not construct from state %s.\n", 
        StateToString(state));
        return DS_ERROR;
  }

  DSResult resp = DebugSocketCreate(&handle);
  if (resp == DS_OK)
    state = DSS_UNBOUND;

  return resp;
}

void DebugSocket::Destruct() {
  if (state != DSS_INVALID) {
    DebugSocketClose(handle);
  }

  handle = (DebugHandle) -1;
  state = DSS_INVALID;
}

DSResult DebugSocket::Bind(const string& addr) {
  if (state != DSS_UNBOUND) {
      NaClLog(LOG_ERROR, "Socket can not bind from state %s.\n", 
        StateToString(state));
        return DS_ERROR;
  }

  DSResult resp = DebugSocketBind(handle, addr);
  if (resp == DS_OK)
    state = DSS_BOUND;

  return resp;
}

DSResult DebugSocket::Accept(DebugSocket **socket) {
  DebugHandle newHandle;
  DebugSocket *newSocket;

  if (state != DSS_LISTEN) {
      NaClLog(LOG_ERROR, "Socket can not accept from state %s.\n", 
        StateToString(state));
        return DS_ERROR;
  }

  string loc;
  DSResult resp = DebugSocketAccept(handle, &newHandle, &loc);
  if (resp == DS_OK) {
    newSocket = new DebugSocket();
    newSocket->handle = newHandle;
    newSocket->state  = DSS_CONNECTED;    
    *socket = newSocket;
  }

  return resp;
}

DSResult DebugSocket::Connect(const string &addr) {
  DSResult resp;

  //Fall through states, until the socket can Connect
  if (state == DSS_INVALID) {
      if (Construct() == DS_ERROR)
        return DS_ERROR;
  }

  if (state == DSS_UNBOUND) {
    resp = DebugSocketConnect(handle, addr);
    if (resp == DS_OK)
      state = DSS_CONNECTED;
    return resp;
  }

  NaClLog(LOG_ERROR, "Socket can not connect from state %s.\n", 
  StateToString(state));
  return DS_ERROR;
}
 

DSResult DebugSocket::Listen(const string &addr, int outstanding) {
  DSResult resp;

  //Fall through states, until the socket can Listen
  if (state == DSS_INVALID) {
      if (Construct() == DS_ERROR)
        return DS_ERROR;
  }
  if (state == DSS_UNBOUND) {
      if (Bind(addr) == DS_ERROR)
        return DS_ERROR;
  }
  if (state == DSS_BOUND) {
      resp = DebugSocketListen(handle, outstanding);
      if (resp == DS_OK)
        state = DSS_LISTEN;
      return resp;
  }

  NaClLog(LOG_ERROR, "Socket can not listen from state %s.\n", 
  StateToString(state));
  return DS_ERROR;
}

DSResult DebugSocket::Read(void *ptr, int max, int *len) {
  return DebugSocketRecv(handle, ptr, max, len);
}

DSResult DebugSocket::Write(void *ptr, int max, int *len) {
  return DebugSocketSend(handle, ptr, max, len);
}

DSResult DebugSocket::CanRead() {
  return DebugSocketCanRecv(handle, msec_timeout);
}
DSResult DebugSocket::CanWrite() {
  return DebugSocketCanSend(handle, msec_timeout);
}
