/*
 * Copyright 2010 The Native Client Authors.  All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#include "native_client/src/shared/platform/nacl_log.h"
#include "native_client/src/trusted/debug_stub/debug_packet.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_util.h"


DebugPacket::DebugPacket() : seq(-1) {}

void DebugPacket::Clear() {
  data.str("");
  seq = -1;
}

void DebugPacket::Rewind() {
  data.seekg(0, ios::beg);
  data.seekp(0, ios::beg);
}

void DebugPacket::AddRawChar(char ch) {
  data << ch;
}

void DebugPacket::AddByte(char ch) {
  char seq1 = debug_int_to_nibble(ch >> 4);
  char seq2 = debug_int_to_nibble(ch & 0xF);

  AddRawChar(seq1);
  AddRawChar(seq2);
}

void DebugPacket::AddBlock(void *ptr, int len) {
  const char *p = (const char *) ptr;

  for (int offs = 0; offs < len; offs++)
    AddByte(p[offs]);
}

void DebugPacket::AddWord16(short val) {
  AddBlock(&val, sizeof(val));
}

void DebugPacket::AddWord32(int val) {
  AddBlock(&val, sizeof(val));
}

void DebugPacket::AddWord64(long long val) {
  AddBlock(&val, sizeof(val));
}

void DebugPacket::AddPointer(void *ptr) {
  return AddBlock(&ptr, sizeof(ptr));
}

void DebugPacket::AddString(const string& str) {
  data << str;
}


DSResult DebugPacket::GetRawChar(char *ch) {
  if (data.eof())
    return DS_NONE;

  data >> *ch;
  return DS_OK;
}

DSResult DebugPacket::GetByte(char *ch) {
  char seq1, seq2;
  DSResult res;

  res = GetRawChar(&seq1);
  res = GetRawChar(&seq2);
	
  *ch  = debug_nibble_to_int(seq1) << 4;
  *ch += debug_nibble_to_int(seq2);

  return res;
}

DSResult DebugPacket::GetBlock(void *ptr, int len) {
  char *p = (char *) ptr;
  DSResult res;

  for (int offs = 0; offs < len; offs++)
    res = GetByte(&p[offs]);

  return res;
}

DSResult DebugPacket::GetWord16(short *ptr) {
  return GetBlock(ptr, sizeof(*ptr));
}

DSResult DebugPacket::GetWord32(int *ptr) {
  return GetBlock(ptr, sizeof(*ptr));
}

DSResult DebugPacket::GetWord64(long long *ptr) {
  return GetBlock(ptr, sizeof(*ptr));
}

DSResult DebugPacket::GetPointer(void **ptr) {
  return GetBlock(ptr, sizeof(*ptr));
}

DSResult DebugPacket::GetString(string *str) {
  if (data.eof())
    return DS_NONE;

  data >> *str;
  return DS_OK;
}

void DebugPacket::GetPayload(string &str) const {
  str = data.str();
}

DSResult DebugPacket::GetSequence(char *ch) const {
  if (seq != -1)
  {
    *ch = seq;
    return DS_OK;
  }

  return DS_NONE;
}

void DebugPacket::SetSequence(int val) {
  seq = val;
}

