/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_PIPE_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_PIPE_H_ 1


class DebugPipe;
class DebugPacket;
class DebugStream;

/*
 * This module provides interfaces for transmitting and receiving
 * packets that conform to the GDB serial line debug protocol.  
 *
 * The packet are transmitted and received in the form of:
 * $[<SQ>:]<C>[<..data...>]#<XS>
 *
 *
 *  Where
 *	<SQ>  : is an optional two hex digit sequence number followed by ':'
 *  <C>   : is a single character Command
 *  <data>: is the optinal paramters, payload, etc... 
 *  <XS>  : is an 8 bit sum as two hex digits preceeded by '#'
 *
 *  Upon receit, the receiver will reply with either
 *  -      : to signal a bad XSUM
 *  +[SQ]  : to signal valid packet with the sequence if provided
 *
 *
 */

#include "native_client/src/trusted/debug_stub/debug_stub.h"

class DebugPipe {
public:
  explicit DebugPipe(DebugStream *io_ptr);
  ~DebugPipe();

  enum {
    DPF_IGNORE_ACK = 1,
  };

public:
  void SetIgnoreAck(int ignore);

  DSResult SendPacketOnly(DebugPacket *packet);

  DSResult SendPacket(DebugPacket *packet);
  DSResult GetPacket(DebugPacket *packet);
  
public:
  DebugStream *io;
  int flags;
};


#endif