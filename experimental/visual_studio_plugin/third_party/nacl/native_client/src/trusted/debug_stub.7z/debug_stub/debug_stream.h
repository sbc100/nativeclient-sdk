/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_STREAM_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_STREAM_H_ 1

#include "native_client/src/trusted/debug_stub/debug_stub.h"

class DebugStream {
public:
  explicit DebugStream();
	virtual ~DebugStream();

public:
	virtual DSResult Read(void *ptr, int max, int *len) = 0;
	virtual DSResult Write(void *ptr, int max, int *len) = 0;
	virtual DSResult CanRead() = 0;
	virtual DSResult CanWrite()= 0;

	virtual DSResult PutChar(char ch);
	virtual DSResult GetChar(char *ch);
  virtual DSResult SetTimeout(int msec);
  
protected:
  DebugHandle handle;
  int         msec_timeout;
};



#endif