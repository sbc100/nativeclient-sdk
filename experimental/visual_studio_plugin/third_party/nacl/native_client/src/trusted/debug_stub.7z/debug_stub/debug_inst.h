/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_INST_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_INST_H_ 1

#include <string>
using std::string;

#include <map>
using std::map;

#include "native_client/src/trusted/debug_stub/debug_stub.h"

class DebugPacket;
class DebugPipe;
class DebugSocket;
class DebugThread;

class DebugInst {
 public:
	explicit DebugInst(const string& name);
  ~DebugInst();

public:
  DSResult ProcessPacket(DebugPacket *in, DebugPacket *out);

protected:
  DebugThread *GetCurrentThread();
  DebugThread *GetThread(int id);

  DSResult GetDataBlock(void *virt, void *dst, int len);
  DSResult SetDataBlock(void *virt, void *src, int len);

  // Communication information
 public:
  string  name;
  DebugSocket* socketServer;
  DebugPipe*   pipe;

  // NEXE Debugging information
 public:
  map<int, DebugThread*> threads;
  int currSignal;
  int currThread;
};

#endif