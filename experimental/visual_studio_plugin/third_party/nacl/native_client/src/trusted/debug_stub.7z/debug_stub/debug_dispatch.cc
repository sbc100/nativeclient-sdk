/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */
#include "native_client/src/shared/platform/nacl_log.h"

#include "native_client/src/trusted/debug_stub/debug_dispatch.h"
#include "native_client/src/trusted/debug_stub/debug_inst.h"
#include "native_client/src/trusted/debug_stub/debug_packet.h"
#include "native_client/src/trusted/debug_stub/debug_pipe.h"
#include "native_client/src/trusted/debug_stub/debug_socket.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_stub_api.h"

DSResult DispatchDebugPacket(DebugPacket *in, DebugPacket *out);

int NaClDebugStubDispatch(DebugHandle obj, int cmd, void *src, int len) {
  DebugInst *inst = (DebugInst *) obj;
  if (inst) {
    NaClLog(LOG_INFO, "Request %s handle %d at %Xh size %d\n",
            inst->name.data(), cmd, src, len);

    switch(cmd) {
      case DAPI_GET_INFO: 
        if (sizeof(DAPIGetInfo) != len)
          return DS_ERROR;
        return DispatchInfo(inst, (DAPIGetInfo *) src);

      case DAPI_TRY_CONN:
        return DispatchTryConn(inst);

      case DAPI_TRY_WORK: 
        return DispatchTryWork(inst);

      case DAPI_SOCKER_SERVER:
        if (src == 0)
          return DS_ERROR;
        
        return DispatchSocketServer(inst, (const char *) src);
    }
  }

  return DS_ERROR;
}

DSResult DispatchInfo(DebugInst *inst, DAPIGetInfo *info) {
  info->pipeCnt = (inst->pipe ? 1 : 0);
  info->threadCnt = (int) inst->threads.size();

  return DS_OK;
}

DSResult DispatchSocketServer(DebugInst *inst, const char *addr) {
  if (inst->socketServer)
    delete inst->socketServer;

  inst->socketServer = new DebugSocket();
  return inst->socketServer->Listen(addr, 1);
}

DSResult DispatchTryConn(DebugInst *inst) {
  if (inst->pipe) {
    NaClLog(LOG_ERROR, 
            "Lookig for connection on instance '%s' with active pipe.\n",
            inst->name.data());
    return DS_ERROR;
  }

  if (inst->socketServer) {
    DebugSocket *client;
    DSResult resp = inst->socketServer->Accept(&client);
    if (resp == DS_ERROR) {
      //On failure kill the server;
      delete inst->socketServer;
      inst->socketServer = 0;
    }

    //If a socket is waiting, then build the pipe
    if (resp == DS_OK)
        inst->pipe = new DebugPipe(client);

    return resp;
  }

  return DS_ERROR;
}

DSResult DispatchTryWork(DebugInst *inst) {
  DSResult res = DS_NONE;

  if (inst->pipe) {
    DebugPacket pkt_in;
    DebugPacket pkt_out;

    DSResult res = inst->pipe->GetPacket(&pkt_in);
    switch(res) {
      case DS_NONE:
        break;
        
      case DS_OK:
        res = inst->ProcessPacket(&pkt_in, &pkt_out);
        if (res == DS_OK)
          return inst->pipe->SendPacket(&pkt_out);
        break;

      case DS_ERROR:
        NaClLog(LOG_ERROR, 
                "%s pipe returned error, freeing it.\n",
                inst->name.data());
        delete inst->pipe;
        inst->pipe = 0;
        break;
    }
  }
  return res;
}

