/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */


#include <stdio.h>

#include "native_client/src/include/portability.h"
#include "native_client/src/shared/platform/nacl_log.h"
#include "native_client/src/shared/platform/nacl_thread.h"

#include "native_client/src/trusted/debug_stub/debug_inst.h"
#include "native_client/src/trusted/debug_stub/debug_packet.h"
#include "native_client/src/trusted/debug_stub/debug_pipe.h"
#include "native_client/src/trusted/debug_stub/debug_stub_api.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_stub_api.h"
#include "native_client/src/trusted/debug_stub/debug_socket_impl.h"
#include "native_client/src/trusted/debug_stub/debug_socket.h"

static void *context[16] = { 
	(void *) 0, (void *) 1, (void *) 2, (void *) 3, 
	(void *) 4, (void *) 5, (void *) 6, (void *) 7,
	(void *) 8, (void *) 9, (void *) 10, (void *) 11,
	(void *) 12, (void *) 13, (void *) 14, (void *) 15
};


int VerifyAddrXVert(const string &in_addr, const string &cmp_addr) {
  string out_addr;

  sockaddr_in saddr;

  int fail = 0;
  if (DebugSocketStrToAddr(in_addr, &saddr, sizeof(saddr)) != DS_OK) {
    printf("Failed to convert string to address.\n");
    fail++;
  }

  if (DebugSocketAddrToStr(&saddr, sizeof(saddr), &out_addr) != DS_OK) {
    printf("Failed to convert string to address.\n");
    fail++;
  }

  if (cmp_addr != out_addr) {
    printf("Failed address convertion %s != %s\n",
      out_addr.data(), cmp_addr.data());
    fail++;
  }

  return fail;
}

#define TXRX_SIZE 1024
int SocketTest() {
  DebugSocket *listen = new DebugSocket();
  DebugSocket *client = new DebugSocket();
  DebugSocket *server = 0;
  int failed = 1;

  char *src = new char[TXRX_SIZE];
  char *dst = new char[TXRX_SIZE];
  int tx = 0, rx = 0;

  memset(dst, 0, TXRX_SIZE);
  for (int a = 0; a < TXRX_SIZE; a++)
    src[a] = static_cast<char>(a);

  string addr="127.0.0.1:4014";

  if (listen->Listen(addr, 1) != DS_OK) {
    printf("Failed to listen on %s\n", addr.data());
    goto SocketFailed;
  }

  if (client->Connect(addr) != DS_OK) {
    printf("Failed to connect to %s\n", addr.data());
    goto SocketFailed;
  }

  if (listen->Accept(&server) != DS_OK) {
    printf("Failed to accept on %s\n", addr.data());
    goto SocketFailed;
  }

  if (client->Write(src, TXRX_SIZE, &tx) != DS_OK) {
    printf("Failed to send on client, reported %d bytes.\n", tx);
    goto SocketFailed;
  }
  if (server->Read(dst, TXRX_SIZE, &rx) != DS_OK) {
    printf("Failed to read on server, reported %d bytes.\n", rx);
    goto SocketFailed;
  }
  if (memcmp(src, dst, TXRX_SIZE)) {
    printf("RX buffer does not match TX buffer client->server.\n", rx);
    goto SocketFailed;
  }

  if (server->Write(src, TXRX_SIZE, &tx) != DS_OK) {
    printf("Failed to send on server, reported %d bytes.\n", tx);
    goto SocketFailed;
  }
  if (client->Read(dst, TXRX_SIZE, &rx) != DS_OK) {
    printf("Failed to read on client, reported %d bytes.\n", rx);
    goto SocketFailed;
  }
  if (memcmp(src, dst, TXRX_SIZE)) {
    printf("RX buffer does not match TX buffer server->client.\n", rx);
    goto SocketFailed;
  }

  // Must have passed
  failed = 0;

 SocketFailed:
  delete listen;
  delete client;

  if (server)
    delete server;

  delete[] src;
  delete[] dst;

  return failed;
}


int DebugInstTest() {
  int failed = 1;
  int errors = 0;
  char tmp[1024];
  string resStr;
  
  string addr("127.0.0.1:4014");
  DAPIGetInfo info;
  DebugSocket *client = 0;
  DebugPipe *pipe   = 0;
  DebugPacket  pkt;

  DebugHandle handle = NaClDebugStubCreate("TestDebug");

  // Verify we start with no pipes or threads
  memset(&info, -1, sizeof(info));
  if (NaClDebugStubDispatch(handle,
      DAPI_GET_INFO,
      &info,
      sizeof(info)) != DS_OK) {
    printf("Failed to get Instance Info.\n");
    goto DebugInstFailed;
  }
  if ((info.pipeCnt != 0) || (info.threadCnt != 0)) {
    printf("Expecting no threads(%d) or pipes(%d).\n",
      info.threadCnt, info.pipeCnt);
    errors++;
  }

  // Create a pipe and make sure it's there
  if (NaClDebugStubDispatch(handle, 
                            DAPI_SOCKER_SERVER, 
                            (void *)addr.data(), 
                            (int ) addr.size()) != DS_OK) {
    printf("Failed to get Instance Info.\n");
    goto DebugInstFailed;
  }

  client = new DebugSocket();
  if (client->Connect(addr) != DS_OK) {
    printf("Failed to connect to server.\n");
    goto DebugInstFailed;
  }

  if (NaClDebugStubDispatch(handle, DAPI_TRY_CONN, 0, 0) != DS_OK) {
    printf("Failed to try to connect.\n");
    goto DebugInstFailed;
  }
  if (NaClDebugStubDispatch(handle, 
    DAPI_GET_INFO, 
    &info, 
    sizeof(info)) != DS_OK) {
    printf("Failed to get Instance Info.\n");
    goto DebugInstFailed;
  }
  if ((info.pipeCnt != 1) || (info.threadCnt != 0)) {
    printf("Expecting no threads(%d) one pipe(%d).\n",
      info.threadCnt, info.pipeCnt);
    errors++;
  }

  // Assign client socket to the client pipe
  pipe = new DebugPipe(client);
  client = 0;

  // Ignore acks, and add timeout so we can run this singly threaded
  pipe->io->SetTimeout(100);
  pipe->IgnoreAck(1);  
  ((DebugInst *) handle)->pipe->io->SetTimeout(1);
  ((DebugInst *) handle)->pipe->IgnoreAck(1);

  // Generate and test a memory fetch request
  pkt.Clear();
  pkt.AddRawChar('m');
  pkt.AddPointer(&context[0]);
  pkt.AddRawChar(',');
  pkt.AddWord16(sizeof(context));

  if (pipe->SendPacket(&pkt) != DS_OK) {
    printf("Failed to send memory request connect.\n");
    goto DebugInstFailed;
  }
  
  if (NaClDebugStubDispatch(handle, DAPI_TRY_WORK, 0, 0) != DS_OK) {
    printf("Failed to try to work.\n");
    goto DebugInstFailed;
  }
  
  memset(tmp, 0xFF, sizeof(context));
  if (pipe->GetPacket(&pkt) != DS_OK) {
    printf("Failed to send memory request connect.\n");
    goto DebugInstFailed;
  }

  pkt.GetBlock(tmp, sizeof(context));
  if (memcmp(tmp, context, sizeof(context))) {
    printf("Result mismatch in mem fetch.\n");
    goto DebugInstFailed;
  }

  // Generate and test a memory set request
  memset(tmp, 0, sizeof(context));
  pkt.Clear();
  pkt.AddRawChar('M');
  pkt.AddPointer(tmp);
  pkt.AddRawChar(',');
  pkt.AddWord16(sizeof(context));
  pkt.AddRawChar(':');
  pkt.AddBlock(context, sizeof(context));

  if (pipe->SendPacket(&pkt) != DS_OK) {
    printf("Failed to send memory request connect.\n");
    goto DebugInstFailed;
  }
  
  if (NaClDebugStubDispatch(handle, DAPI_TRY_WORK, 0, 0) != DS_OK) {
    printf("Failed to try to work.\n");
    goto DebugInstFailed;
  }
  
  if (memcmp(tmp, context, sizeof(context))) {
    printf("Result mismatch in mem set.\n");
    goto DebugInstFailed;
  }

  if (pipe->GetPacket(&pkt) != DS_OK) {
    printf("Failed to get memory set response.\n");
    goto DebugInstFailed;
  }

  if (pkt.GetString(&resStr) != DS_OK) {
    printf("Failed to retrieve memory reponse string.\n");
    goto DebugInstFailed;
  }
    
  if (resStr != "OK") {
    printf("Failed got '%s' instead of 'OK' as retrieve resp.\n", 
            resStr.data());
    goto DebugInstFailed;
  }


  // Must have passed
  failed = 0;

 DebugInstFailed:
  if (pipe)
    delete pipe;

  if (client)
    delete client;


  NaClDebugStubDestroy(handle);
  return failed + errors;
}

#include <stdio.h> 
#include <windows.h> // for EXCEPTION_ACCESS_VIOLATION 
#include <excpt.h> 

int ExceptionCatch(unsigned int code, struct _EXCEPTION_POINTERS *ep) { 
   puts("in filter."); 
   if (code == EXCEPTION_ACCESS_VIOLATION) { 
   } 
   return EXCEPTION_EXECUTE_HANDLER;
}

volatile int exit_spin = 0;
void Spin(void *arg) {
  int a=0;

  __try { 
    while(!exit_spin) {
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      a++;
      Sleep(0);
    }
   } __except(ExceptionCatch(GetExceptionCode(), GetExceptionInformation())) { 
      printf("Caught Exception.\n");
      return;
   } 
}

#define DEBUG_BREAK 0xCC
void insert_break(void *ptr)
{
	unsigned char *p = (unsigned char *) ptr; //_ReturnAddress();
	DWORD oldflags;
	
	if (!VirtualProtect(p, 64, PAGE_EXECUTE_READWRITE ,&oldflags))
	{
		printf("Failed with %d\n", GetLastError());
	}
	else
	{
		*p = DEBUG_BREAK;
		VirtualProtect(p, 64, oldflags, 0);
		FlushInstructionCache(GetCurrentProcess(), p, 64);
	}
}


int ExceptionTest() {
  char *p = 0;
  DWORD id;

  HANDLE thread = CreateThread(0, 0, (LPTHREAD_START_ROUTINE) Spin, 0, 0, &id);
  printf("Created thread %d, %d\n", thread, id);

  Sleep(1000);

  int cnt = SuspendThread(thread);
  if (cnt == -1) {
      printf("Failed to suspend.\n");
  } else {
    CONTEXT ctx;
    memset(&ctx, 0, sizeof(ctx));
    Sleep(1000);
    ctx.ContextFlags = CONTEXT_CONTROL;
    if (0 == GetThreadContext(thread, &ctx))
      printf("Failed to Get Context with error %d.\n", GetLastError());
    else {
      printf("EIP=%llX\n", ctx.Rip);
      insert_break((void *) ctx.Rip);
    }
    //SetThreadContext(thread, &ctx);
    ResumeThread(thread);
  }


#if 0
   __try { 
      *p = 1;
   } __except(ExceptionCatch(GetExceptionCode(), GetExceptionInformation())) { 
      return 0;
   } 
#endif
   Sleep(1000);
   exit_spin = 1;
   return 0;
}


int main(int argc, char* argv[]) {
  UNREFERENCED_PARAMETER(argc);
  UNREFERENCED_PARAMETER(argv);
  int errors = 0;


  NaClLogModuleInit();
  NaClDebugStubInit();   

  // Verify Address translation
  errors += VerifyAddrXVert("", "0.0.0.0:0");
  errors += VerifyAddrXVert("0", "0.0.0.0:0");
  errors += VerifyAddrXVert(":", "0.0.0.0:0");
  errors += VerifyAddrXVert("0:", "0.0.0.0:0");
  errors += VerifyAddrXVert(":0", "0.0.0.0:0");
  errors += VerifyAddrXVert(":4014", "0.0.0.0:4014");
  errors += VerifyAddrXVert("127.0.0.1", "127.0.0.1:0");
  errors += VerifyAddrXVert("127.0.0.1:4014", "127.0.0.1:4014");

  // Verify Socket
  errors += SocketTest();

  // Verify DebugInst
  errors += DebugInstTest();

  // Verify Handler
  errors += ExceptionTest();

  NaClDebugStubFini();
  NaClLogModuleFini();

  if (errors == 0)
  {
    printf("PASS\n");    return 0;
  } 

  printf("FAILED\n");
  return -1;
}
