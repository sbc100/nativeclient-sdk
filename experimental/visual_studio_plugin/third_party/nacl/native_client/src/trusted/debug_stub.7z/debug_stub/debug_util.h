/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_UTIL_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_UTIL_H_ 1

// Convert between 4bit value and ASCII 0-F hex.
int debug_nibble_to_int(char ch);
char debug_int_to_nibble(int nibble);

// Debug Logging
void dbg_printf(const char *fmt, ...);


#endif
