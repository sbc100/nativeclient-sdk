/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_SOCKET_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_SOCKET_H_ 1

#include <string>
using std::string;

#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_stream.h"

class DebugSocket : public DebugStream {
public:
  DebugSocket();
  ~DebugSocket();

public:
  enum DSState {
    DSS_INVALID   = 0, //No Socket
    DSS_UNBOUND   = 1, //Has Socket, but is unbound
    DSS_BOUND     = 2, //Socket has been bound
    DSS_LISTEN    = 3, //Socket is listening for connections
    DSS_CONNECTED = 4, //Socket is connected
  };

protected:
  DSResult Construct();  
  void Destruct();
  DSResult Bind(const string& addr);

public:
  DSResult Accept(DebugSocket **socket);
  DSResult Connect(const string &addr);
  DSResult Listen(const string &addr, int outstanding);

  DSResult Read(void *ptr, int max, int *len);
  DSResult Write(void *ptr, int max, int *len);
  DSResult CanRead();
  DSResult CanWrite();

protected:
  DSState state;
};

#endif