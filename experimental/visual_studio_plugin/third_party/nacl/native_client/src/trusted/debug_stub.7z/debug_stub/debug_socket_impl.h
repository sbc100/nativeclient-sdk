/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_SOCKET_IMPL_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_SOCKET_IMPL_H_ 1

#include <string>
using std::string;

#include "native_client/src/trusted/debug_stub/debug_stream.h"

// Platform dependant socket calls
// NOTE:  Also prevents us from needing to including windows.h/winsock.h
DSResult DebugSocketCreate(DebugHandle *handle);
DSResult DebugSocketClose(DebugHandle handle);

DSResult DebugSocketAccept(DebugHandle srvSock, DebugHandle *newSock, string *addr);
DSResult DebugSocketBind(DebugHandle handle, const string &addr);
DSResult DebugSocketConnect(DebugHandle handle, const string &addr);
DSResult DebugSocketListen(DebugHandle handle, int cnt);
DSResult DebugSocketRecv(DebugHandle handle, void *data, int max, int *len);
DSResult DebugSocketSend(DebugHandle handle, void *data, int max, int *len);
DSResult DebugSocketCanRecv(DebugHandle handle, int msec_timeout);
DSResult DebugSocketCanSend(DebugHandle handle, int msec_timeout);

DSResult DebugSocketStrToAddr(const string &saddr, void *daddr, int len);
DSResult DebugSocketAddrToStr(void *saddr, int len, string *dstr);


#endif
