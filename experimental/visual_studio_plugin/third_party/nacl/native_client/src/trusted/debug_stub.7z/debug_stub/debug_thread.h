/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_THREAD_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_THREAD_H_ 1

#define MACHINE_REG_CNT 16

class DebugThread  {
public:
  DebugThread();
  ~DebugThread();

 public:
  void *registers[MACHINE_REG_CNT];
};

#endif