/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_STUB_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_STUB_H_ 1

#include "native_client/src/include/nacl_base.h"

EXTERN_C_BEGIN

// Handle for any OS dependant handle, or 'C' object reference
typedef void *DebugHandle;

// The result of any DebugStub Operation
enum DSResult { 
	  DS_ERROR = -1,    //Error on the object
	  DS_NONE  = 0,     //Nothing to do
	  DS_OK    = 1      //Success
  };


void NaClDebugStubInit();
void NaClDebugStubFini();

//
// Platform-specific init/fini functions
//
void NaClDebugStubPlatformInit();
void NaClDebugStubPlatformFini();


//
// Interface for creating and destroying a debug instance
//
DebugHandle NaClDebugStubCreate(const char *name);
void NaClDebugStubDestroy(DebugHandle obj);

//
// Interface for sending a command to a debug instance
//
int NaClDebugStubDispatch(DebugHandle obj, int cmd, void *src, int len);

EXTERN_C_END

#endif
