/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */
#include "native_client/src/shared/platform/nacl_log.h"
#include "native_client/src/trusted/debug_stub/debug_dispatch.h"
#include "native_client/src/trusted/debug_stub/debug_inst.h"
#include "native_client/src/trusted/debug_stub/debug_packet.h"
#include "native_client/src/trusted/debug_stub/debug_pipe.h"
#include "native_client/src/trusted/debug_stub/debug_socket.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"
#include "native_client/src/trusted/debug_stub/debug_thread.h"



DebugHandle NaClDebugStubCreate(const char *name) {
  DebugInst *inst = new DebugInst(name);
  return (DebugHandle) inst;
}

void NaClDebugStubDestroy(DebugHandle obj) {
  DebugInst *inst = (DebugInst *) obj;
  delete inst;
}

DebugInst::DebugInst(const string &obj_name) :
  name(obj_name),
  socketServer(0),
  pipe(0),
  currThread(0),
  currSignal(0) {
    NaClLog(LOG_INFO, "Created DebugInst '%s'.\n", name.data());
}

DebugInst::~DebugInst() {
    NaClLog(LOG_INFO, "Destroyed DebugInst '%s'.\n", name.data());
    if (socketServer)
      delete socketServer;
}

DebugThread *DebugInst::GetCurrentThread() {
  return GetThread(currThread);
}

DebugThread *DebugInst::GetThread(int id) {
  if (threads.count(id)) {
    DebugThread *thread = threads[id];
    if (thread)
      return thread;

      NaClLog(LOG_INFO, 
              "Attempting to access a dead thread %d(%x).\n", 
              name.data(), 
              id, 
              id);
  } else {
      NaClLog(LOG_INFO,
              "Attempting to access a thread we do not own.\n",
              name.data(), 
              id, 
              id);
  }
  return 0;
}

DSResult DebugInst::GetDataBlock(void *virt, void *dst, int len) {
  memcpy(dst, virt, len);
  return DS_OK;
}

DSResult DebugInst::SetDataBlock(void *virt, void *src, int len) {
  memcpy(virt, src, len);
  return DS_OK;
}


DSResult DebugInst::ProcessPacket(DebugPacket *in, DebugPacket *out) {
	char cmd;
	DSResult resp = DS_OK;

	//Clear the outbound message
	out->Clear();

	//Find the command
	in->GetRawChar(&cmd);

	switch (cmd) {
		//Return the last signal triggered
		case '?':
			out->AddRawChar('S');
			out->AddByte(currSignal);
			break;

		//Return the value of the CPU registers
		case 'g':
      {
        DebugThread *thread = GetCurrentThread();
        if (thread) {
  			  out->AddBlock(thread->registers, sizeof(thread->registers));
        }
        else
          out->AddString("E01");
      }
      break;

		//Set the value of the CPU registers, and return OK
		case 'G':
      {
        DebugThread *thread = GetCurrentThread();
        if (thread) {
          in->GetBlock(thread->registers, sizeof(thread->registers));
	  		  out->AddString("OK");
        } else
          out->AddString("E01");
      }
			break;

		case 'm':
		{
			void *ptr;
			short len;
			char sep;

			in->GetPointer(&ptr);
			in->GetRawChar(&sep);
			if (sep == ',') {
				in->GetWord16(&len);

				//Allocate a TMP block for the transfer
				char *block = new char[(int) len];

				//Attempt a fetch which may fail
				if (GetDataBlock(ptr, block, (int) len))
					out->AddBlock(block, (int) len);
				else
					out->AddString("E03");

				//Free the tmp block;
				delete[] block;
			} else {
				out->AddString("E01");
			}	
			break;
		}
		case 'M':
		{
			void *ptr;
			short len;
			char sep;

			in->GetPointer(&ptr);
			in->GetRawChar(&sep);

			if (sep == ',') {
				in->GetWord16(&len);
				in->GetRawChar(&sep);
				if (sep == ':') {
					//Allocate a TMP block for the transfer
					char *block = new char[(int) len];

					//Copy data to tmp block
					in->GetBlock(block, (int) len);

					//Attempt a set which may fail
					if (SetDataBlock(ptr, block, (int) len))
						out->AddString("OK");
					else
						out->AddString("E03");

					//Free the tmp block;
					delete[] block;
				} else {
					out->AddString("E01");
				}
			} else {
				out->AddString("E01");
			}		
			break;
		}
		case 's':
		case 'c':
			resp = DS_NONE;
			break;
	}

	return resp;
}

