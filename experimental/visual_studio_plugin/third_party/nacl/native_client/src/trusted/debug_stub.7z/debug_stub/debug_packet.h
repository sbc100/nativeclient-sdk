/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_PACKET_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_PACKET_H_ 1

#include <sstream>
using namespace std;

#include "native_client/src/trusted/debug_stub/debug_stub.h"

/*
 * This module provides interfaces for creating and viewing debug
 * packets that conform to the GDB serial line debug protocol. The packet
 * must not contain the special characters '$' or '#' which are used by
 * the transport/framing layer to denote start and end of packets.
 *
 * All binary is expected to be cooked and convered into a pair of hex 
 * nibbles per byte.  Data is stored as a stream, where the first char
 * is expected to be and uncooked command ID, followed by optional
 * arguments which may be raw or cooked.
 *
 * In addition, packets may be sequenced by setting an 8 bit sequence number,
 * which helps both sides detect when packets have been lost.  By default the
 * sequence number is not set.
 */

#include "native_client/src/trusted/debug_stub/debug_stub.h"

class DebugPacket 
{
public:
  DebugPacket();

public:
  void Clear();
  void Rewind();

  void AddRawChar(char ch);
  void AddByte(char ch);
  void AddBlock(void *ptr, int len);
  void AddString(const string& str);
  void AddPointer(void *ptr);
  void AddWord16(short val);
  void AddWord32(int val);
  void AddWord64(long long val);

public:
  DSResult GetRawChar(char *ch);
  DSResult GetByte(char *ch);
  DSResult GetBlock(void *ptr, int len);
  DSResult GetString(string *str);
  DSResult GetPointer(void **ptr);
  DSResult GetWord16(short *val);
  DSResult GetWord32(int *val);
  DSResult GetWord64(long long *val);

public:
  DSResult GetSequence(char *ch) const;
  void SetSequence(int ch);

public:
  void GetPayload(string& str) const;

private:
  int	seq;
  stringstream data;
};
#endif