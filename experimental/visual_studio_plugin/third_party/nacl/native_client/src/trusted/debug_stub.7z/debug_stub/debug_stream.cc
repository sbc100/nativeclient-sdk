/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#include "native_client/src/trusted/debug_stub/debug_stream.h"

DebugStream::DebugStream()
 : msec_timeout(0),
   handle(0) {}

DebugStream::~DebugStream() {};

DSResult DebugStream::SetTimeout(int msec) {
  if (msec < 0)
    return DS_ERROR;
  
  msec_timeout = msec;
  return DS_OK;
}

DSResult DebugStream::PutChar(char ch) {
  int cnt;
  return Write(&ch, 1, &cnt);
}

DSResult DebugStream::GetChar(char *ch) {
  int cnt;
  return Read(ch, 1, &cnt);
}


