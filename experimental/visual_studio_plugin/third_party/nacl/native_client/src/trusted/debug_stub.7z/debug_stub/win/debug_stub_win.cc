/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#include "native_client/src/include/nacl_base.h"
#include "native_client/src/shared/platform/nacl_log.h"
#include "native_client/src/trusted/debug_stub/debug_stub.h"

#include <winsock2.h>

static int s_SocketsAvailible = 0;

void NaClDebugStubPlatformInit() {

  WORD wVersionRequested;
  WSADATA wsaData;
  int err;

  // Make sure to request the use of sockets.
  // NOTE:  It is safe to call Startup multiple times
  wVersionRequested = MAKEWORD(2, 2);
  err = WSAStartup(wVersionRequested, &wsaData);
  if (err != 0) {
	  // We could not find a matching DLL
	  NaClLog(LOG_ERROR, "WSAStartup failed with error: %d\n", err);
	  return;
  }

  if (HIBYTE(wsaData.wVersion) != 2) 
  {
	  // We couldn't get a matching version
	  NaClLog(LOG_ERROR, "Could not find a usable version of Winsock.dll\n");
	  WSACleanup();
	  return;
  }

  s_SocketsAvailible = 1;
} 

void NaClDebugStubPlatformFini() {
  // Make sure to signal we are done with sockets
  // NOTE:  It must be called as many times as Startup.
  if (s_SocketsAvailible)
  {
	  s_SocketsAvailible = 0;
	  WSACleanup();
  }
}

