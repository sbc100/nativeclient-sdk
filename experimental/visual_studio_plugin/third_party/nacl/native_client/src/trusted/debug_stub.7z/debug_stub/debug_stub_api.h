/*
 * Copyright 2008 The Native Client Authors. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can
 * be found in the LICENSE file.
 */

#ifndef NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_STUB_API_H_
#define NATIVE_CLIENT_SRC_TRUSTED_DEBUG_STUB_DEBUG_STUB_API_H_ 1

#include "native_client/src/include/nacl_base.h"

enum {
  // Create a server socket to wait for connections.
  DAPI_GET_INFO = 1,      // Get general information
  DAPI_TRY_CONN = 2,      // Try and connect
  DAPI_TRY_WORK = 3,      // Try and process packets
  DAPI_SOCKER_SERVER = 4, // Create a socket server
};


struct DAPIGetInfo {
  int threadCnt;
  int pipeCnt;
};

struct DAPIAddThread {
};

#endif
